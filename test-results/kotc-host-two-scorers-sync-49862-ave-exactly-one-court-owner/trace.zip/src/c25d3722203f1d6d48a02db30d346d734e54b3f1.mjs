import { test, expect } from '@playwright/test';

const APP_ID=process.env.VITE_BASE44_APP_ID||'6a01dc00702b7dd2a2978c28';
const json=(route,body,status=200)=>route.fulfill({status,contentType:'application/json',body:JSON.stringify(body)});
const now=()=>Date.now();

function createModel(){
  const participants=Array.from({length:18},(_,i)=>({id:`participant-${String(i+1).padStart(2,'0')}`,player_id:`player-${String(i+1).padStart(2,'0')}`,display_name:`Player ${String(i+1).padStart(2,'0')}`,status:'present',seed_rank:i+1}));
  const slots=[];const matches=[];
  for(let c=1;c<=4;c++){
    const ids=participants.slice((c-1)*4,c*4).map(p=>p.id);
    slots.push(
      {id:`slot-${c}-a1`,round_id:'round-1',round_number:1,ladder_court_rank:c,team_side:'A',slot_number:1,participant_id:ids[0]},
      {id:`slot-${c}-a2`,round_id:'round-1',round_number:1,ladder_court_rank:c,team_side:'A',slot_number:2,participant_id:ids[1]},
      {id:`slot-${c}-b1`,round_id:'round-1',round_number:1,ladder_court_rank:c,team_side:'B',slot_number:1,participant_id:ids[2]},
      {id:`slot-${c}-b2`,round_id:'round-1',round_number:1,ladder_court_rank:c,team_side:'B',slot_number:2,participant_id:ids[3]},
    );
    matches.push({id:`match-${c}`,session_id:'session-live',round_id:'round-1',round_number:1,ladder_court_rank:c,team_a_participant_ids:ids.slice(0,2),team_b_participant_ids:ids.slice(2),status:'scheduled',revision:0,team_a_score:null,team_b_score:null,scoring_lock_owner:null,scoring_lock_expires_at:null,scorer_correction_owner_client_id:null});
  }
  const model={
    calls:[],participants,slots,matches,rateLimits:{},
    round:{id:'round-1',session_id:'session-live',round_number:1,status:'started',proposal_revision:1,active_court_count:4,bench_count:2},
    session:{id:'session-live',tournament_id:'e2e-kotc-tournament',name:'Collaborative Score E2E',status:'in_progress',current_round_number:1,current_round_id:'round-1',revision:2,play_minutes:8,scoring_mode:'timed',score_target:11,win_by_two:false,timer_state_json:JSON.stringify({roundId:'round-1',roundNumber:1,durationSeconds:480,remainingSeconds:420,running:true,deadlineAt:new Date(Date.now()+420000).toISOString(),lastAction:'start'})},
  };
  model.setRateLimit=(source,name,action,count=1)=>{model.rateLimits[`${source}:${name}:${action}`]=count;};
  const active=m=>!!(m.scoring_lock_owner&&m.scoring_lock_expires_at&&Date.parse(m.scoring_lock_expires_at)>now());
  const names=Object.fromEntries(participants.map(p=>[p.id,p.display_name]));
  const currentMatches=()=>model.matches.filter(m=>String(m.round_id)===String(model.session.current_round_id));
  const liveScorePayload=()=>({liveScoresOnly:true,session:{id:model.session.id,status:model.session.status,current_round_id:model.session.current_round_id,current_round_number:model.session.current_round_number,revision:model.session.revision,timer_state_json:model.session.timer_state_json},matches:currentMatches().map(m=>({id:m.id,status:m.status,team_a_score:m.team_a_score,team_b_score:m.team_b_score,winner_side:m.winner_side,serving_side_at_horn:m.serving_side_at_horn,result_method:m.result_method,revision:m.revision,correction_count:0,completed_at:m.completed_at,command_id:m.command_id,scoring_lock_active:active(m),scoring_lock_kind:active(m)?(String(m.scoring_lock_owner).startsWith('host:')?'host':'player'):'none',scoring_lock_expires_at:active(m)?m.scoring_lock_expires_at:null}))});
  const correctionOpen=(m,clientId)=>m.status==='completed'&&m.scorer_correction_owner_client_id===clientId&&m.completed_at&&Date.now()-Date.parse(m.completed_at)<=90000;
  const scorerState=clientId=>({success:true,session:{name:model.session.name,status:model.session.status,current_round_number:model.session.current_round_number,scoring_mode:'timed',score_target:11,win_by_two:false},round:{id:model.round.id,round_number:model.round.round_number,status:model.round.status},bench:['Player 17','Player 18'],timer:{running:true,remainingSeconds:420,deadlineAt:new Date(Date.now()+420000).toISOString()},matches:currentMatches().map(m=>({id:m.id,court:m.ladder_court_rank,status:m.status,revision:m.revision,team_a:m.team_a_participant_ids.map(id=>names[id]),team_b:m.team_b_participant_ids.map(id=>names[id]),team_a_score:m.team_a_score,team_b_score:m.team_b_score,winner_side:m.winner_side,lock_status:active(m)?(m.scoring_lock_owner===clientId?'mine':'other'):'free',lock_seconds:active(m)?Math.ceil((Date.parse(m.scoring_lock_expires_at)-now())/1000):0,can_correct:correctionOpen(m,clientId),correction_seconds_remaining:correctionOpen(m,clientId)?Math.max(0,Math.ceil((Date.parse(m.completed_at)+90000-Date.now())/1000)):0}))});
  model.handle=async(source,name,body)=>{
    model.calls.push({source,name,body:{...body},at:Date.now()});
    const actionKey=String(body.action||body.commandType||(body.liveScoresOnly?'liveScoresOnly':'state'));const rateKey=`${source}:${name}:${actionKey}`;
    if(Number(model.rateLimits[rateKey]||0)>0){model.rateLimits[rateKey]-=1;return {status:429,body:{error:'Rate limit exceeded'}};}
    if(name==='getKotcV2State'){
      if(body.liveScoresOnly)return liveScorePayload();
      return {session:model.session,participants:model.participants,rounds:[model.round],slots:model.slots,matches:model.matches,fixedPairs:[],scorerLinkActive:true,contactDirectory:{},currentAccessRole:'admin',isAdmin:true};
    }
    if(name==='kotcTimer')return {success:true,state:JSON.parse(model.session.timer_state_json)};
    if(name==='kotcScorer'){
      const action=body.action||'state',clientId=body.clientId||'';
      if(action==='state')return scorerState(clientId);
      const m=currentMatches().find(x=>x.id===body.matchId);if(!m)return {status:404,body:{error:'Current-round match not found'}};
      if(action==='claim'){
        if(m.status==='completed'&&!correctionOpen(m,clientId))return {status:423,body:{error:`Court ${m.ladder_court_rank} is already saved. The scorer correction window has closed; the host can still correct this result.`,saved:true,read_only:true}};
        const mine=model.matches.find(x=>x.id!==m.id&&x.scoring_lock_owner===clientId&&active(x));if(mine)return {status:423,body:{error:`This device is already scoring Court ${mine.ladder_court_rank}. Save or cancel that court first.`,locked:true}};
        if(active(m)&&m.scoring_lock_owner!==clientId)return {status:423,body:{error:`Court ${m.ladder_court_rank} is being scored on another device.`,locked:true}};
        await new Promise(r=>setTimeout(r,10));m.scoring_lock_owner=clientId;m.scoring_lock_expires_at=new Date(Date.now()+90000).toISOString();await new Promise(r=>setTimeout(r,35));
        if(m.scoring_lock_owner!==clientId||!active(m))return {status:423,body:{error:`Court ${m.ladder_court_rank} was claimed by another scorer.`,locked:true}};
        return {success:true,claimed:true,lease_seconds:90,expires_at:m.scoring_lock_expires_at};
      }
      if(action==='heartbeat'){
        if(!active(m)||m.scoring_lock_owner!==clientId)return {status:423,body:{error:'Your scoring lock is no longer active.'}};
        m.scoring_lock_expires_at=new Date(Date.now()+90000).toISOString();return {success:true};
      }
      if(action==='release'){
        if(m.scoring_lock_owner===clientId){m.scoring_lock_owner=null;m.scoring_lock_expires_at=null;}return {success:true,released:true};
      }
      if(action==='save'||action==='correct'){
        if(!active(m)||m.scoring_lock_owner!==clientId)return {status:423,body:{error:`Court ${m.ladder_court_rank} is not locked to this scorer.`}};
        if(Number(body.expectedRevision)!==m.revision)return {status:409,body:{error:'This score changed since you opened it.'}};
        const correcting=action==='correct';if(correcting&&!correctionOpen(m,clientId))return {status:423,body:{error:'The 90-second scorer correction window has closed. Ask the host to correct this result.'}};
        m.team_a_score=Number(body.teamAScore);m.team_b_score=Number(body.teamBScore);m.winner_side=m.team_a_score>m.team_b_score?'A':'B';m.status='completed';m.revision+=1;if(!correcting)m.completed_at=new Date().toISOString();m.scoring_lock_owner=null;m.scoring_lock_expires_at=null;m.scorer_correction_owner_client_id=clientId;
        return {success:true,message:correcting?'Updated score saved':'Score saved',match:{...m,can_correct:correctionOpen(m,clientId),correction_seconds_remaining:correctionOpen(m,clientId)?Math.max(0,Math.ceil((Date.parse(m.completed_at)+90000-Date.now())/1000)):0,lock_status:'free'}};
      }
    }
    if(name==='kotcCommand'&&body.commandType==='host_claim_score'){
      const m=model.matches.find(x=>x.id===body.matchId);if(!m)return {status:404,body:{error:'Match not found'}};
      const correction=body.forCorrection===true;
      if(m.status==='completed'&&!correction)return {status:409,body:{error:`Court ${m.ladder_court_rank} has already been saved. Refresh player scores to load the result before making any correction.`,saved:true,refresh_required:true}};
      if(m.status!=='completed'&&correction)return {status:409,body:{error:`Court ${m.ladder_court_rank} has not been saved yet.`}};
      if(active(m)&&m.scoring_lock_owner!=='host:host-e2e')return {status:423,body:{error:correction?`Court ${m.ladder_court_rank} is already being corrected on another device.`:`Court ${m.ladder_court_rank} is already being entered by a player. Wait for them to save or cancel, then refresh player scores.`,locked:true}};
      await new Promise(r=>setTimeout(r,10));m.scoring_lock_owner='host:host-e2e';m.scoring_lock_expires_at=new Date(Date.now()+90000).toISOString();await new Promise(r=>setTimeout(r,35));
      if(m.scoring_lock_owner!=='host:host-e2e'||!active(m))return {status:423,body:{error:`Court ${m.ladder_court_rank} was claimed by another scorer.`,locked:true}};
      return {success:true,hostAuthority:true,expires_at:m.scoring_lock_expires_at};
    }
    if(name==='kotcCommand'&&body.commandType==='host_release_score'){
      const m=model.matches.find(x=>x.id===body.matchId);if(m?.scoring_lock_owner==='host:host-e2e'){m.scoring_lock_owner=null;m.scoring_lock_expires_at=null;}return {success:true,released:true};
    }
    if(name==='kotcCommand'&&body.commandType==='correct_match'){
      const m=model.matches.find(x=>x.id===body.matchId);if(!m)return {status:404,body:{error:'Match not found'}};
      if(!active(m)||m.scoring_lock_owner!=='host:host-e2e')return {status:423,body:{error:'This saved score is being corrected elsewhere or your correction lock expired. Refresh before trying again.',locked:true}};
      if(Number(body.expectedMatchRevision)!==m.revision)return {status:409,body:{error:'Match changed since you opened it.'}};
      m.team_a_score=Number(body.teamAScore);m.team_b_score=Number(body.teamBScore);m.winner_side=m.team_a_score>m.team_b_score?'A':'B';m.revision+=1;m.scoring_lock_owner=null;m.scoring_lock_expires_at=null;m.scorer_correction_owner_client_id=null;return {success:true,match:{...m},correction:true};
    }
    if(name==='saveKotcScore'){
      const m=model.matches.find(x=>x.id===body.matchId);if(!m)return {status:404,body:{error:'Match not found'}};
      if(active(m)&&m.scoring_lock_owner!=='host:host-e2e')return {status:423,body:{error:`Court ${m.ladder_court_rank} is already being entered by a player.`}};
      if(Number(body.expectedMatchRevision)!==m.revision)return {status:409,body:{error:'Match changed since you opened it.'}};
      m.team_a_score=Number(body.teamAScore);m.team_b_score=Number(body.teamBScore);m.winner_side=m.team_a_score>m.team_b_score?'A':'B';m.status='completed';m.revision+=1;m.completed_at=new Date().toISOString();m.scoring_lock_owner=null;m.scoring_lock_expires_at=null;m.scorer_correction_owner_client_id=null;return {success:true,match:{...m}};
    }
    return {success:true};
  };
  return model;
}

async function install(context,model,source){
  await context.route('**/api/apps/**',async route=>{
    const req=route.request(),url=new URL(req.url()),marker=`/api/apps/${APP_ID}/functions/`;
    if(!url.pathname.includes(marker))return json(route,[]);
    const name=decodeURIComponent(url.pathname.split(marker)[1]?.split('/')[0]||'');let body={};try{body=req.postDataJSON()||{};}catch{}
    const out=await model.handle(source,name,body);if(out?.status)return json(route,out.body,out.status);return json(route,out);
  });
}

async function openScorer(context){const page=await context.newPage();await page.goto('/e2e/kotcScorerHarness.html');await expect(page.getByText('Collaborative Score E2E')).toBeVisible();return page;}
async function fillCourt(page,court,a,b){const card=page.getByTestId(`scorer-court-${court}`);await card.locator('input').nth(0).fill(String(a));await card.locator('input').nth(1).fill(String(b));return card;}

test('host + two scorer devices: first claim wins, mixed parallel scoring, manual host refresh only',async({browser})=>{
  test.setTimeout(60000);
  const model=createModel();
  const hostCtx=await browser.newContext({viewport:{width:1280,height:900}}),aCtx=await browser.newContext({viewport:{width:390,height:844}}),bCtx=await browser.newContext({viewport:{width:390,height:844}});
  await install(hostCtx,model,'host');await install(aCtx,model,'scorer-a');await install(bCtx,model,'scorer-b');
  const host=await hostCtx.newPage();await host.goto('/e2e/kotcHarness.html');await expect(host.getByText('Round 1 — LIVE')).toBeVisible();
  await expect(host.getByTestId('kotc-refresh-player-scores')).toBeVisible();

  // No background host score polling: wait longer than the old polling interval.
  const before=model.calls.filter(c=>c.source==='host'&&c.name==='getKotcV2State'&&c.body.liveScoresOnly).length;
  await host.waitForTimeout(4500);
  expect(model.calls.filter(c=>c.source==='host'&&c.name==='getKotcV2State'&&c.body.liveScoresOnly).length).toBe(before);

  const [a,b]=await Promise.all([openScorer(aCtx),openScorer(bCtx)]);
  const scorerStateBefore=model.calls.filter(c=>c.name==='kotcScorer'&&c.body.action==='state').length;
  await a.waitForTimeout(5500);
  expect(model.calls.filter(c=>c.name==='kotcScorer'&&c.body.action==='state').length).toBe(scorerStateBefore);
  await a.getByTestId('scorer-court-1').locator('input').nth(0).fill('1');
  await b.getByTestId('scorer-court-2').locator('input').nth(0).fill('7');
  await expect(a.getByTestId('scorer-court-1')).toContainText('locked to you');
  await expect(b.getByTestId('scorer-court-2')).toContainText('locked to you');

  // Host learns ownership only when deliberately refreshing; claimed player courts become unavailable to host.
  await host.getByTestId('kotc-refresh-player-scores').click();
  await expect(host.getByTestId('kotc-score-card-1')).toContainText('Player entering this court');
  await expect(host.getByTestId('kotc-score-1-a')).toBeDisabled();
  await expect(host.getByTestId('kotc-score-card-2')).toContainText('Player entering this court');
  await expect(host.getByTestId('kotc-score-2-a')).toBeDisabled();

  // Host claims a different free court on the first actual digit. The scorer page does not poll;
  // one explicit scorer refresh reveals the host lock.
  await host.getByTestId('kotc-score-3-a').fill('6');
  await expect(host.getByTestId('kotc-score-card-3')).toContainText('HOST ENTERING');
  await a.getByTestId('scorer-refresh').click();
  await expect(a.getByTestId('scorer-court-3')).toContainText(/host or another scorer|LOCKED/);

  // All three can score in parallel on separate courts.
  const cardA=await fillCourt(a,1,11,1),cardB=await fillCourt(b,2,7,8);
  await host.getByTestId('kotc-score-3-b').fill('4');
  await Promise.all([
    cardA.getByRole('button',{name:'Save Result'}).click(),
    cardB.getByRole('button',{name:'Save Result'}).click(),
    host.getByTestId('kotc-complete-3').click(),
  ]);
  await expect(cardA).toContainText('Score saved: 11–1');await expect(cardB).toContainText('Score saved: 7–8');await expect(host.getByTestId('kotc-score-card-3')).toContainText('Saved 6–4');

  // Player saves do not magically appear on host: host has only its local Court 3 result until a deliberate action.
  await expect(host.getByTestId('kotc-next-action')).toContainText('1/4 scores saved');
  await expect(host.getByTestId('kotc-player-score-toolbar')).toBeVisible();
  await expect(host.getByTestId('kotc-player-score-toolbar')).toContainText('1/4 saved');
  const toolbarBeforeCourtOne=await host.evaluate(()=>{const toolbar=document.querySelector('[data-testid="kotc-player-score-toolbar"]'),court=document.querySelector('[data-testid="kotc-score-card-1"]');if(!toolbar||!court)return false;return !!(toolbar.compareDocumentPosition(court)&Node.DOCUMENT_POSITION_FOLLOWING);});
  expect(toolbarBeforeCourtOne,'Player Scores refresh toolbar should sit immediately before the court score grid').toBe(true);
  const refreshReadsBefore=model.calls.filter(c=>c.source==='host'&&c.name==='getKotcV2State'&&c.body.liveScoresOnly).length;
  await host.waitForTimeout(1500);
  expect(model.calls.filter(c=>c.source==='host'&&c.name==='getKotcV2State'&&c.body.liveScoresOnly).length).toBe(refreshReadsBefore);

  // Normal manual refresh pulls both player saves in and remains cheap.
  await host.getByTestId('kotc-refresh-player-scores').click();
  await expect(host.getByTestId('kotc-next-action')).toContainText('3/4 scores saved');
  await expect(host.getByTestId('kotc-score-card-1')).toContainText('Saved 11–1');
  await expect(host.getByTestId('kotc-score-card-2')).toContainText('Saved 7–8');

  // Host can take the remaining free court on first digit and finish the round locally.
  await host.getByTestId('kotc-score-4-a').fill('9');await host.getByTestId('kotc-score-4-b').fill('5');await host.getByTestId('kotc-complete-4').click();
  await expect(host.getByText('All scores saved for Round 1')).toBeVisible();

  await hostCtx.close();await aCtx.close();await bCtx.close();
});

test('stale host cannot type over a helper score that was already saved',async({browser})=>{
  const model=createModel();
  const hostCtx=await browser.newContext({viewport:{width:1280,height:900}}),scorerCtx=await browser.newContext({viewport:{width:390,height:844}});
  await install(hostCtx,model,'host');await install(scorerCtx,model,'scorer-a');
  const host=await hostCtx.newPage();await host.goto('/e2e/kotcHarness.html');await expect(host.getByText('Round 1 — LIVE')).toBeVisible();
  const scorer=await openScorer(scorerCtx);

  // Host deliberately never refreshes after the helper starts. From the host's stale local view Court 1 still looks free.
  const helperCard=await fillCourt(scorer,1,11,2);await helperCard.getByRole('button',{name:'Save Result'}).click();
  await expect(helperCard).toContainText('Score saved: 11–2');
  await expect(host.getByTestId('kotc-score-1-a')).toHaveValue('');
  await expect(host.getByTestId('kotc-score-1-a')).toBeEnabled();

  // First attempted host digit hits the authoritative claim endpoint. Because the helper already saved,
  // the digit must never appear; the UI performs one lightweight refresh and renders 11–2 instead.
  await host.getByTestId('kotc-score-1-a').fill('5');
  await expect(host.getByTestId('kotc-score-card-1')).toContainText('Saved 11–2');
  await expect(host.getByTestId('kotc-score-1-a')).toHaveValue('11');
  expect(model.matches[0].team_a_score).toBe(11);expect(model.matches[0].team_b_score).toBe(2);expect(model.matches[0].revision).toBe(1);
  expect(model.calls.some(c=>c.source==='host'&&c.name==='kotcCommand'&&c.body.commandType==='host_claim_score')).toBe(true);

  await hostCtx.close();await scorerCtx.close();
});

test('same-millisecond host/helper first digits leave exactly one court owner',async({browser})=>{
  const model=createModel();
  const hostCtx=await browser.newContext({viewport:{width:1280,height:900}}),scorerCtx=await browser.newContext({viewport:{width:390,height:844}});
  await install(hostCtx,model,'host');await install(scorerCtx,model,'scorer-a');
  const host=await hostCtx.newPage();await host.goto('/e2e/kotcHarness.html');await expect(host.getByText('Round 1 — LIVE')).toBeVisible();
  const scorer=await openScorer(scorerCtx);
  const hostInput=host.getByTestId('kotc-score-1-a'),scorerInput=scorer.getByTestId('scorer-court-1').locator('input').nth(0);

  await Promise.allSettled([hostInput.fill('8'),scorerInput.fill('9')]);
  await host.waitForTimeout(250);
  const scorerClaim=model.calls.find(c=>c.source==='scorer-a'&&c.name==='kotcScorer'&&c.body.action==='claim');
  const scorerClient=scorerClaim?.body.clientId;
  const owner=model.matches[0].scoring_lock_owner;
  expect(['host:host-e2e',scorerClient]).toContain(owner);
  expect(owner).toBeTruthy();

  if(owner==='host:host-e2e'){
    await expect(hostInput).toHaveValue('8');
    await expect(scorerInput).toHaveValue('');
    await host.getByTestId('kotc-score-card-1').getByRole('button',{name:'Cancel'}).click();
    await scorer.getByTestId('scorer-refresh').click();
    await scorerInput.fill('4');await expect(scorerInput).toHaveValue('4');
  }else{
    await expect(scorerInput).toHaveValue('9');
    await expect(hostInput).toHaveValue('');
    await scorer.getByTestId('scorer-court-1').getByRole('button',{name:'Cancel'}).click();
    await host.getByTestId('kotc-refresh-player-scores').click();
    await hostInput.fill('4');await expect(hostInput).toHaveValue('4');
  }
  expect(model.matches[0].scoring_lock_owner).toBeTruthy();
  await hostCtx.close();await scorerCtx.close();
});

test('host/helper simultaneous correction attempts use first-claim-wins correction lock',async({browser})=>{
  const model=createModel();
  const hostCtx=await browser.newContext({viewport:{width:1280,height:900}}),scorerCtx=await browser.newContext({viewport:{width:390,height:844}});
  await install(hostCtx,model,'host');await install(scorerCtx,model,'scorer-a');
  const host=await hostCtx.newPage();await host.goto('/e2e/kotcHarness.html');await expect(host.getByText('Round 1 — LIVE')).toBeVisible();
  const scorer=await openScorer(scorerCtx);

  const helperCard=await fillCourt(scorer,1,11,2);await helperCard.getByRole('button',{name:'Save Result'}).click();await expect(helperCard).toContainText('Score saved: 11–2');
  await host.getByTestId('kotc-refresh-player-scores').click();await expect(host.getByTestId('kotc-score-card-1')).toContainText('Saved 11–2');
  const hostEdit=host.getByTestId('kotc-score-card-1').getByRole('button',{name:'Edit result'}),helperEdit=helperCard.getByRole('button',{name:/Undo \/ Update Score/});
  await Promise.allSettled([hostEdit.click(),helperEdit.click()]);
  await host.waitForTimeout(250);

  const scorerClaim=[...model.calls].reverse().find(c=>c.source==='scorer-a'&&c.name==='kotcScorer'&&c.body.action==='claim');
  const scorerClient=scorerClaim?.body.clientId;const owner=model.matches[0].scoring_lock_owner;
  expect(['host:host-e2e',scorerClient]).toContain(owner);
  if(owner==='host:host-e2e'){
    await host.getByTestId('kotc-score-1-a').fill('12');await host.getByTestId('kotc-score-1-b').fill('3');
    await host.getByTestId('kotc-score-card-1').getByRole('button',{name:'Save Correction'}).click();
  }else{
    await helperCard.locator('input').nth(0).fill('12');await helperCard.locator('input').nth(1).fill('3');
    await helperCard.getByRole('button',{name:'Save Updated Score'}).click();
  }
  await expect.poll(()=>model.matches[0].revision).toBe(2);
  expect(model.matches[0].team_a_score).toBe(12);expect(model.matches[0].team_b_score).toBe(3);expect(model.matches[0].scoring_lock_owner).toBe(null);
  await hostCtx.close();await scorerCtx.close();
});

test('stale helper correction button cannot bypass the 90-second correction window',async({browser})=>{
  const model=createModel();
  const hostCtx=await browser.newContext({viewport:{width:1280,height:900}}),scorerCtx=await browser.newContext({viewport:{width:390,height:844}});
  await install(hostCtx,model,'host');await install(scorerCtx,model,'scorer-a');
  const host=await hostCtx.newPage();await host.goto('/e2e/kotcHarness.html');await expect(host.getByText('Round 1 — LIVE')).toBeVisible();
  const scorer=await openScorer(scorerCtx);const card=await fillCourt(scorer,1,11,2);await card.getByRole('button',{name:'Save Result'}).click();
  await expect(card).toContainText('Score saved: 11–2');await expect(card.getByRole('button',{name:/Undo \/ Update Score/})).toBeVisible();

  // Simulate the helper leaving this stale page open until the server-side 90-second window expires.
  model.matches[0].completed_at=new Date(Date.now()-91000).toISOString();
  await card.getByRole('button',{name:/Undo \/ Update Score/}).click();
  await expect(card.getByRole('button',{name:/Undo \/ Update Score/})).toHaveCount(0);
  await expect(card).toContainText('Result already entered');
  expect(model.matches[0].revision).toBe(1);expect(model.matches[0].team_a_score).toBe(11);expect(model.matches[0].team_b_score).toBe(2);

  // Host authority to correct remains available after the helper window closes.
  await host.getByTestId('kotc-refresh-player-scores').click();await expect(host.getByTestId('kotc-score-card-1')).toContainText('Saved 11–2');
  await host.getByTestId('kotc-score-card-1').getByRole('button',{name:'Edit result'}).click();await expect(host.getByTestId('kotc-score-card-1')).toContainText('HOST ENTERING');
  await host.getByTestId('kotc-score-card-1').getByRole('button',{name:'Cancel'}).click();
  await hostCtx.close();await scorerCtx.close();
});

test('Prepare Next Round immediately cuts off helper correction rights even on a stale scorer screen',async({browser})=>{
  const model=createModel();const scorerCtx=await browser.newContext({viewport:{width:390,height:844}});await install(scorerCtx,model,'scorer-a');
  const scorer=await openScorer(scorerCtx);const card=await fillCourt(scorer,1,11,3);await card.getByRole('button',{name:'Save Result'}).click();
  await expect(card).toContainText('Score saved: 11–3');await expect(card.getByRole('button',{name:/Undo \/ Update Score/})).toBeVisible();

  // Simulate host preparing/starting Round 2 while helper still has the old Round 1 screen open.
  const round2Matches=model.matches.slice(0,4).map((m,i)=>({...m,id:`match-r2-${i+1}`,round_id:'round-2',round_number:2,status:'scheduled',revision:0,team_a_score:null,team_b_score:null,winner_side:null,completed_at:null,scoring_lock_owner:null,scoring_lock_expires_at:null,scorer_correction_owner_client_id:null}));
  model.matches.push(...round2Matches);model.round={id:'round-2',session_id:model.session.id,round_number:2,status:'started',proposal_revision:1,active_court_count:4,bench_count:2};model.session.current_round_number=2;model.session.current_round_id='round-2';model.session.revision+=1;

  // Stale helper action must be rejected against the old match, then refresh to the new round.
  await card.getByRole('button',{name:/Undo \/ Update Score/}).click();
  await expect(scorer.getByText('Round 2')).toBeVisible();await expect(scorer.getByTestId('scorer-court-1')).not.toContainText('Score saved: 11–3');
  await expect(scorer.getByTestId('scorer-court-1').getByRole('button',{name:/Undo \/ Update Score/})).toHaveCount(0);
  expect(model.matches[0].revision).toBe(1);expect(model.matches[0].team_a_score).toBe(11);expect(model.matches[0].team_b_score).toBe(3);
  await scorerCtx.close();
});

test('four scorer phones recover from simultaneous 429 claim/save burst with bounded calls',async({browser})=>{
  test.setTimeout(60000);
  const model=createModel();
  const hostCtx=await browser.newContext({viewport:{width:1280,height:900}});await install(hostCtx,model,'host');
  const host=await hostCtx.newPage();await host.goto('/e2e/kotcHarness.html');await expect(host.getByText('Round 1 — LIVE')).toBeVisible();
  const contexts=[],pages=[];
  for(let i=1;i<=4;i++){
    const ctx=await browser.newContext({viewport:{width:390,height:844}});contexts.push(ctx);await install(ctx,model,`scorer-${i}`);pages.push(await openScorer(ctx));
    model.setRateLimit(`scorer-${i}`,'kotcScorer','claim',1);model.setRateLimit(`scorer-${i}`,'kotcScorer','save',1);
  }
  const stateBefore=model.calls.filter(c=>c.name==='kotcScorer'&&c.body.action==='state').length;
  await pages[0].waitForTimeout(5500);
  expect(model.calls.filter(c=>c.name==='kotcScorer'&&c.body.action==='state').length).toBe(stateBefore);

  await Promise.all(pages.map((p,i)=>p.getByTestId(`scorer-court-${i+1}`).locator('input').nth(0).fill(String(i+1))));
  for(let i=0;i<4;i++){
    const card=pages[i].getByTestId(`scorer-court-${i+1}`);await expect(card).toContainText('locked to you');await expect(card).not.toContainText(/rate limit/i);
    await card.locator('input').nth(0).fill('11');await card.locator('input').nth(1).fill(String(i+1));
  }

  await Promise.all(pages.map((p,i)=>p.getByTestId(`scorer-court-${i+1}`).getByRole('button',{name:'Save Result'}).click()));
  for(let i=0;i<4;i++){const card=pages[i].getByTestId(`scorer-court-${i+1}`);await expect(card).toContainText(`Score saved: 11–${i+1}`);await expect(card).not.toContainText(/rate limit/i);}
  expect(model.matches.every(m=>m.status==='completed'&&m.revision===1&&!m.scoring_lock_owner)).toBe(true);

  await expect(host.getByTestId('kotc-player-score-toolbar')).toContainText('0/4 saved');
  await host.getByTestId('kotc-refresh-player-scores').click();await expect(host.getByText('All scores saved for Round 1')).toBeVisible();
  await expect(host.getByTestId('kotc-player-score-toolbar')).toContainText('4/4 saved');

  const scorerCalls=model.calls.filter(c=>c.name==='kotcScorer');
  const claimCalls=scorerCalls.filter(c=>c.body.action==='claim').length,saveCalls=scorerCalls.filter(c=>c.body.action==='save').length,stateCalls=scorerCalls.filter(c=>c.body.action==='state').length,heartbeatCalls=scorerCalls.filter(c=>c.body.action==='heartbeat').length;
  expect(claimCalls).toBe(8);expect(saveCalls).toBe(8);expect(stateCalls).toBeLessThanOrEqual(8);expect(heartbeatCalls).toBe(0);
  console.log('KOTC COLLABORATIVE SCORING PRESSURE',JSON.stringify({claimCalls,saveCalls,stateCalls,heartbeatCalls,totalScorerCalls:scorerCalls.length,hostLiveRefreshes:model.calls.filter(c=>c.source==='host'&&c.name==='getKotcV2State'&&c.body.liveScoresOnly).length},null,2));

  for(const ctx of contexts)await ctx.close();await hostCtx.close();
});
